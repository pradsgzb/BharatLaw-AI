# BharatLaw AI — architecture and Codex handoff

**Design version:** 1.0 · **Date:** 19 September 2026

This is an implementation-ready **architecture/specification package**, with reference SQL, schemas, OpenSearch mappings, an API contract, small executable reference algorithms and synthetic tests. It is **not** the completed BharatLaw web application, an ingested legal corpus, a deployed AWS environment, or a legal-compliance certification.

## Start here

Read `docs/ARCHITECTURE.md` for the full design and `CODEX_START_HERE.md` for the implementation prompt. Codex must also follow `AGENTS.md`. The initial goal is a working authenticated source catalog and exact-source viewer, before LLM generation or autonomous workflows.

## Package contents

| File/directory | Purpose |
|---|---|
| `docs/ARCHITECTURE.md` | Complete architecture, data model, RAG, graph, bounded agents, AWS and evaluation design |
| `db/reference_schema.sql` | PostgreSQL reference DDL: canonical corpus, temporal data, graph, release snapshots, tenants, runs, audit and privacy |
| `contracts/*.schema.json` | Strict document, research request and answer contracts |
| `contracts/openapi.yaml` | OpenAPI 3.1 reference endpoints and typed request/response schemas |
| `opensearch/*.index.json` | Concrete public/private chunk and document index mappings |
| `config/` | Fail-closed policy, pending source rights and provider-profile registers |
| `reference/` | Small pure-Python retrieval, quote-integrity and temporal-selection examples |
| `examples/` | Labelled synthetic document, request, answer and release manifest; no real Indian legal claims |
| `tests/` | Executable reference/contract tests and planned evaluation scenarios |
| `docs/API_AND_WORKFLOWS.md` | Endpoint semantics, auth, SSE, idempotency, uploads, deletion and exports |
| `docs/SECURITY_AND_OPERATIONS.md` | Threat model, infrastructure modules, IAM, privacy/retention and runbooks |
| `docs/IMPLEMENTATION_PLAN.md` | Phases, 44 tickets and evidence-based exit gates |
| `AGENTS.md` | Repository-level constraints for Codex |
| `CODEX_START_HERE.md` | Copy-paste implementation prompt and milestone continuation |
| `VALIDATION_REPORT.md` | Exactly what was tested, what passed and what was not executed |
| `MANIFEST.sha256` | Package file checksums, excluding this manifest itself |

## Reference test setup

Use Python 3.11 or a newer compatible maintained version in a virtual environment:

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# PowerShell:  .\.venv\Scripts\Activate.ps1
python -m pip install -r requirements-reference.txt
python -m pytest -q
```

These commands test the included pure-Python reference algorithms and contract consistency. They do not start the product or prove AWS, PostgreSQL or OpenSearch behavior. See the validation report. Install dependencies only into an appropriate development environment; production dependency selection, security review and lockfiles remain implementation work.

## Important defaults

Real-source acquisition, private uploads and production deployment are disabled. Provider profiles and retention approvals are unset. The vector dimension `1024` is a **reference mapping parameter**, not a recommendation of a specific embedding model. Resolve the actual approved model/profile before indexing; change mappings and reindex when necessary.

No external model calls, paid services, production deployment or live source crawling were performed for this package. Only synthetic content is included. Do not confuse official-site availability with permission to perform every downstream use.

## Implementation status

The handoff establishes the intended structure and critical invariants. Codex must build the real application, turn SQL into tested migrations, implement authorization and provider adapters, apply and test index mappings, provision approved infrastructure, acquire approved sources, conduct lawyer-reviewed evaluation and perform operational/security tests before launch.

The architecture references official source and platform documentation inspected during preparation. Recheck source terms, legal commencement, service compatibility and approved provider routes at implementation time. Proposed quality, latency, availability, cost caps and recovery figures are targets, not achieved measurements.
